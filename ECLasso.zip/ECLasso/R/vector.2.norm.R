vector.2.norm <-
function(x) {
  sqrt(sum(x^2));
}
