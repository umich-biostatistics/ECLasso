##credit to Nick Gotelli at https://gotellilab.github.io/GotelliLabMeetingHacks/NickGotelli/ColorPalettes.html
addalpha<-function(colors, alpha=1.0) {
  r <- col2rgb(colors, alpha=T)
  # Apply alpha
  r[4,] <- alpha*255
  r <- r/255.0
  return(rgb(r[1,], r[2,], r[3,], r[4,]))
}